package product.interfaces;

public interface Input {
    String input();
}
