package product.validation;

import java.util.Scanner;

public interface Input {
   static Scanner sc = new Scanner(System.in);
    String input();
}
